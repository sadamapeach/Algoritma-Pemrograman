#ifndef SEQUENTIAL_H_INCLUDED
#define SEQUENTIAL_H_INCLUDED

void SEQSearchX1(int T[], int N, int *IX, int X);

#endif // SEQUENTIAL_H_INCLUDED
