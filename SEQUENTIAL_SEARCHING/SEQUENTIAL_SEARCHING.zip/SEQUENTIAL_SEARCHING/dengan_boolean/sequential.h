#include <stdbool.h>

#ifndef SEQUENTIAL_H_INCLUDED
#define SEQUENTIAL_H_INCLUDED

void SEQSearchX2(int T[], int N, int X, int *IX, bool *Found);

#endif // SEQUENTIAL_H_INCLUDED
